module.exports=(function(){
  return {
    name:"GlNetbirdView",
    render:function(h){
      return h("div",{style:"margin:0;padding:0;height:calc(100vh - 64px)"},[
        h("iframe",{
          attrs:{src:"/netbird/",frameborder:"0",scrolling:"auto"},
          style:"width:100%;height:100%;border:none;display:block"
        })
      ]);
    }
  };
})()
